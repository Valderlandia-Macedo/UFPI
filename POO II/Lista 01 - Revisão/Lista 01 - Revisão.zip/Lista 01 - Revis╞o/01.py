Farenheit = float(input('Temperatura em Farenheit = '))
Celsius = (5 * (Farenheit - 32) / 9)
print('Temperatura em Celsius = {} °C'.format(Celsius))